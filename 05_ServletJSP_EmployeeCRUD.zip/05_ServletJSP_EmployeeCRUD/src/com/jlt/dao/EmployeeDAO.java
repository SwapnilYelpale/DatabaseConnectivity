package com.jlt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jlt.Factory.ConnectionFactory;
import com.jlt.controller.Employee;


public class EmployeeDAO {
	private Connection connection;
	private PreparedStatement preparedStatement;
	private int rowCount;
	private String sql;
	private  ResultSet resultSet;

	public boolean addNewEmployee(Employee employee) {
		
		
		try {
			sql = "insert into employee(first_name,last_name,salary,email) values(?,?,?,?)";
			connection = new ConnectionFactory().getDBConnection();
			if (connection != null) {
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.setString(1, employee.getFirstname());
				preparedStatement.setString(2, employee.getLastname());
				preparedStatement.setDouble(3, employee.getSalary());
				preparedStatement.setString(4, employee.getEmail());

				rowCount = preparedStatement.executeUpdate();
				connection.close();

				if (rowCount > 0)
					return true;
			}
		} catch (SQLException e) {
			System.out.println("Exception :: " + e.getMessage());
		}
		return false;
	}
	
	public List<Employee> getAllEmployee()
	{
		return null;
	}
	
	public List<Employee> getAllEmployees()
	{
		try {
			sql="select * from employee";
			connection=new ConnectionFactory().getDBConnection();
			preparedStatement=connection.prepareStatement(sql);
			resultSet=preparedStatement.executeQuery();
			java.util.List<Employee> employeeList=new ArrayList<Employee>();
			
			while(resultSet.next()) {
				Employee employee =new Employee();
				
				employee.setEmployeeid(resultSet.getInt("employeeid"));

				employee.setFirstname(resultSet.getString("firstname"));

				employee.setLastname(resultSet.getString("lastname"));

				employee.setSalary(resultSet.getDouble("salary"));

				employee.setEmail(resultSet.getString("email"));
				
				System.out.println(employee);
				employeeList.add(employee);
				
			}
			connection.close();
			return employeeList;
		}catch (Exception e) {
			System.out.println("Exception ::"+e.getMessage());
		}
		return null;
	}
	
	
	public boolean deleteEmployee(int employeeId)
	{
		try {
			sql="delete from employee where employee_id=?";
			connection=new ConnectionFactory().getDBConnection();
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setInt(1, employeeId);
			rowCount=preparedStatement.executeUpdate();
			if(rowCount>0) {
				return true ;
			}
			catch (Exception e)
			{
				System.out.println("Exception ::" +e.getMessage());
			}
		
		
		}
}
	}
