package com.jlt.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jlt.dao.EmployeeDAO;


@WebServlet("/EmployeeCRUDServlet")
public class EmployeeCRUDServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String option=request.getParameter("option");
		int employeeId;
		switch (option){
		case "Add Employee":
				response.sendRedirect("addEmployee.html");
				break;
		
		case "Delete":
		 employeeId =Integer.valueOf(request.getParameter("dbAction"));
			if(new EmployeeDAO().deleteEmployee(employeeId))
			response.sendRedirect("index.jsp");
			break;

		}
		}
}