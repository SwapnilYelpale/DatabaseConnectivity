package com.jlt.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jlt.dao.EmployeeDAO;

@WebServlet("/AddEmployeeServlet")
public class AddEmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String firstname=request.getParameter("txtfirstname");
		String lastname =request.getParameter("txtlastname");
		double salary=Double.valueOf(request.getParameter("txtsalary"));
		String email=request.getParameter("txtemail");
		
		
		Employee employee=new Employee(0,firstname,lastname,salary,email);
		
		
		
		System.out.println(employee);
		
		EmployeeDAO employeeDAO=new EmployeeDAO();
		if(employeeDAO.addNewEmployee(employee))
		{
			response.sendRedirect("index.jsp");
		}else {
			response.sendRedirect("error.jsp");
		}
		
		
		
		System.out.println(firstname);
		System.out.println(lastname);
		System.out.println(salary);
		System.out.println(email);
	}

}
