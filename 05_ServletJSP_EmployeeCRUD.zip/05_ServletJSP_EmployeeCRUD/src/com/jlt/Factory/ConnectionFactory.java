package com.jlt.Factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
	String url = "jdbc:sqlserver://localhost:1433;databasename=JLTDB;integratedSecurity=true";
	private Connection connection;
	
	public Connection getDBConnection()
	{
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url);
			if(connection != null)
			{
				return connection;
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Exception: " + e.getMessage());
		}
		return null;
		
	}

}
