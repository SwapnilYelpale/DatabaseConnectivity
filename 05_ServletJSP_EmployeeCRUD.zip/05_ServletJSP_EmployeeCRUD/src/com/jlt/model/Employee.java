package com.jlt.model;

public class Employee {

}
